/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formularios;

import conexiones.ConexionMySQL;
import interfaces.AccionesDB;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author medrano
 */
public class Sentencias implements AccionesDB {

    public String cod;
    public String nombre1;
    public String nombre2;
    public String nombre3;
    public String nombre4;
    public String apellido1;
    public String apellido2;
    public String apellido3;
    public String apellido4;
    public String direccion;
    public String edad;
    public String telefono;
    public String dui;
    public String pastor;
    public String direccion_iglesia;
    public String fui_miembro;
    public String tiempo_miembro;
    public String privilegio_desenpeno;
    
    /*
    
 /  public String municipio; //262
    public String departamento; //14
    public String estado_civil; //c,s,v,d
    public String foto;
    public String fecha_solicitud; // yyyy-mm-dd
    public String fecha_nacimiento; // yyyy-mm-dd
    
    
    public String labora; //si, no
    public String trabajo_ocupacion;
    public String direccion_trabajo;
    public String nombre_empresa_negocio;
    public String ingresos;
    
    //calificacion membresia
    
    public String pregunta1; //si, no
    public String pregunta2; //si, no
    public String pregunta3; //si, no
    public String pregunta4; //si, no  
    public String pregunta5; //si, no
    public String pregunta6; //si, no
    public String pregunta7; //si, no
    public String pregunta8; //si, no
    public String pregunta9; //si, no   
    
    
    
    
    */

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getNombre1() {
        return nombre1;
    }

    public void setNombre1(String nombre1) {
        this.nombre1 = nombre1;
    }

    public String getNombre2() {
        return nombre2;
    }

    public void setNombre2(String nombre2) {
        this.nombre2 = nombre2;
    }

    public String getNombre3() {
        return nombre3;
    }

    public void setNombre3(String nombre3) {
        this.nombre3 = nombre3;
    }

    public String getNombre4() {
        return nombre4;
    }

    public void setNombre4(String nombre4) {
        this.nombre4 = nombre4;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getApellido3() {
        return apellido3;
    }

    public void setApellido3(String apellido3) {
        this.apellido3 = apellido3;
    }

    public String getApellido4() {
        return apellido4;
    }

    public void setApellido4(String apellido4) {
        this.apellido4 = apellido4;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDui() {
        return dui;
    }

    public void setDui(String dui) {
        this.dui = dui;
    }

    public String getPastor() {
        return pastor;
    }

    public void setPastor(String pastor) {
        this.pastor = pastor;
    }

    public String getDireccion_iglesia() {
        return direccion_iglesia;
    }

    public void setDireccion_iglesia(String direccion_iglesia) {
        this.direccion_iglesia = direccion_iglesia;
    }

    public String getFui_miembro() {
        return fui_miembro;
    }

    public void setFui_miembro(String fui_miembro) {
        this.fui_miembro = fui_miembro;
    }

    public String getTiempo_miembro() {
        return tiempo_miembro;
    }

    public void setTiempo_miembro(String tiempo_miembro) {
        this.tiempo_miembro = tiempo_miembro;
    }

    public String getPrivilegio_desenpeno() {
        return privilegio_desenpeno;
    }

    public void setPrivilegio_desenpeno(String privilegio_desenpeno) {
        this.privilegio_desenpeno = privilegio_desenpeno;
    }

    @Override
    public void insertarDB() {
        ConexionMySQL conexion = new ConexionMySQL();

        Connection conn = conexion.getConexion();
        Statement st;

        String sql = "insert into dato (nombre1, nombre2, nombre3, nombre4, apellido1, apellido2, apellido3, apellido4, direccion, edad, telefono, dui, pastor, direccion_iglesia, fui_miembro, tiempo_miembro, privilegio_desenpeno)"
                + " values('" + getNombre1() + "','" + getNombre2() + "','" + getNombre3() + "','" + getNombre4() + "','" + getApellido1() + "','" + getApellido2() + "','" + getApellido3() + "','" + getApellido4() + "','" + getDireccion() + "','" + getEdad() + "','" + getTelefono() + "','" + getDui() + "','" + getPastor() + "','" + getDireccion_iglesia() + "','" + getFui_miembro() + "','" + getTiempo_miembro() + "','" + getPrivilegio_desenpeno() + "')";

        try {
            st = conn.createStatement();

            st.executeUpdate(sql);
            conn.close();
            st.close();

        } catch (SQLException e) {
            e.setNextException(e);
        }
    }

    @Override
    public void selectDB() {
        ConexionMySQL conexion = new ConexionMySQL();

        Connection conn = conexion.getConexion();
        Statement st;

        String sql = "SELECT * FROM dato where id_usuario=" + this.getCod();

        try {
            st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {

                this.setNombre1(rs.getString(2));
                this.setNombre2(rs.getString(3));
                this.setNombre3(rs.getString(4));
                this.setNombre4(rs.getString(5));
                this.setApellido1(rs.getString(6));
                this.setApellido2(rs.getString(7));
                this.setApellido3(rs.getString(8));
                this.setApellido4(rs.getString(9));
                this.setDireccion(rs.getString(10));
                this.setEdad(rs.getString(11));
                this.setTelefono(rs.getString(12));
                this.setDui(rs.getString(13));
                this.setPastor(rs.getString(14));
                this.setDireccion_iglesia(rs.getString(15));
                this.setFui_miembro(rs.getString(16));
                this.setTiempo_miembro(rs.getString(17));
                this.setPrivilegio_desenpeno(rs.getString(18));

            }
            conn.close();
            st.close();

        } catch (SQLException e) {
        }
    }

    @Override
    public void actualizarDB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void eliminarDB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public DefaultTableModel actualizarTabla() {

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("id");
        modelo.addColumn("Nombre1");
        modelo.addColumn("Nombre2");
        modelo.addColumn("Nombre3");
        modelo.addColumn("Nombre4");
        modelo.addColumn("Apellido1");
        modelo.addColumn("Apellido2");
        modelo.addColumn("Apellido3");
        modelo.addColumn("Apellido4");
        modelo.addColumn("Dui");
        modelo.addColumn("Telefono");
        modelo.addColumn("Pastor");

        ConexionMySQL conexion = new ConexionMySQL();
        Connection conn = conexion.getConexion();

        Statement st;

        String sql = "SELECT * FROM dato";

        String[] datos = new String[17];

        try {
            st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {

                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                datos[5] = rs.getString(6);
                datos[6] = rs.getString(7);
                
                datos[7] = rs.getString(8);
                datos[8] = rs.getString(9);
                
                datos[9] = rs.getString(10);
                datos[10] = rs.getString(11);
                
                datos[11] = rs.getString(12);
                datos[12] = rs.getString(13);
                datos[13] = rs.getString(14);
                datos[14] = rs.getString(15);
                datos[15] = rs.getString(16);
                datos[16] = rs.getString(17);
                
                modelo.addRow(datos);
            }
            conn.close();
            st.close();
        } catch (SQLException e) {
        }
        return modelo;
    }
}
