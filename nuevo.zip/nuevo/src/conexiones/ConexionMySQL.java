/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexiones;


import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;

/**
 *
 * @author medrano
 */
public class ConexionMySQL {
    private static final String servidor = "jdbc:mysql://localhost:3307/pruebas";
    private static final String user = "root";
    private static final String pass = "";
    private static final String driver = "com.mysql.jdbc.Driver";
    private static Connection conexion;

    public ConexionMySQL() {

        try {
            Class.forName(driver);
            conexion = DriverManager.getConnection(servidor, user, pass);
            System.out.println("Conexión iniciada con exito");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Conexión Fallida");
        }
    }

    public Connection getConexion() {
        return conexion;
    }
}
